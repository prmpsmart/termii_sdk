from setuptools import setup

setup(
    name="termii_sdk",
    version="0.1",
    packages=['termii_sdk'],
    install_requires=["requests"],
)
